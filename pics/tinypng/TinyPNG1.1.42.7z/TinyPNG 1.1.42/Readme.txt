1.Step1, Open "1.Registry Entry" folder, and double check it for import registry entry to your Regeidit.



2.Step2, Open "2.Install" folder, and install TinPNG with TinyPNG-v1.1.exe.



3.Step3, Open "3.For PSCC 2014" folder, and copy all in this folder to your Photoshop CC 2014 main root and replace them. And run Photoshop CC 2014, open an any PNG file, and go to File---> Export--->TinyPNG...



4. Enjoy It!!





There is a script for batch image processor for TinyPNG inculded.

Go to run your Photoshop, and File--->Scripts---->TinyPNG Image Processor


Pay Attention!!!!!!!!!!!!!!!!!!!!

This script convert your PNG files, it's direct overwrite your original PNG files to the same folder, so make sure you got backup before you use this script.

And this script only can batch process PNG files.